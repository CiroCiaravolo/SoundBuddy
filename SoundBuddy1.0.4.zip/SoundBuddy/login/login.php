<?php
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: /");
}
else {
    $dbconn = pg_connect("host=localhost port=5432 dbname=Soundbuddy
    user=postgres password=Cirorita1") 
                or die('Could not connect: ' . pg_last_error());
}
?>
<html lang="it"></html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatibile" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> SuondBuddy</title>
    <link rel="stylesheet" href="../stili.css" >
    <script src="https://code.jquery.com/jquery-3.6.4.min.js">
  </script>
    <script>
    $(document).ready(function(){
        $("#bottone_1").click(function(){
        $("#negative").detach();
        $("#positive").css("color", "red");
        });
        $("#bottone_2").click(function(){
        $("#positive").detach();
        $("#negative").css("color", "red");
        });
        $("#reset").click(function () {
	    location.reload();
        });
    });
    $(document).ready(function () {
      $(".filtrare").click(function () {
        $("#tutorial").animate({ top: '134%' });
      });
      $(".filtrare").mouseleave(function () {
        $("#tutorial").fadeOut();
      });
      $(".filtrare").mouseenter(function () {
        $("#tutorial").fadeIn();
      });
      $(".cercare").click(function () {
        $("#tutorial").animate({ top: '158%' });
      });
      $(".cercare").mouseleave(function () {
        $("#tutorial").fadeOut();
      });
      $(".cercare").mouseenter(function () {
        $("#tutorial").fadeIn();
      });
      $(".scegliere").click(function () {
        $("#tutorial").animate({ top: '184%' });
      });
      $(".scegliere").mouseleave(function () {
        $("#tutorial").fadeOut();
      });
      $(".scegliere").mouseenter(function () {
        $("#tutorial").fadeIn();
      });
      $(".filtra").click(function () {
        $(".movimento").slideToggle();
      });
    });
    </script>
    </head>

    <body>
        <?php
            if ($dbconn) {
                $email = $_POST['inputEmail'];
                $q1 = "select * from utente where email= $1";
                $result = pg_query_params($dbconn, $q1, array($email));
                if (!($tuple=pg_fetch_array($result, null, PGSQL_ASSOC))) {
                    header("Location: ../index.html");
                }
                else {
                    $password = $_POST['inputPassword'];
                    $q2 = "select * from utente where email = $1";
                    $result = pg_query_params($dbconn, $q2, array($email));
                    $tuple=pg_fetch_array($result, null, PGSQL_ASSOC);
                    if (!(password_verify($password, $tuple['paswd']))) {
                        header("Location: ../index2.html");
                    }
                }
            }
        ?> 
        <header>
        <p class="welcome-message">
        <?php
            $username = $tuple['username'];
            echo "Welcome $username";
        ?>
        </p>
        <img src="../logo.jpg.png"/>
        <nav class="navigation">
            <form action="logout.php" class="form-signin m-auto" 
                method="POST" name="myForm">
                <button type="submit" class="btn">LogOut</button>
            </form>
        </nav>  
        <button id="tutorial" style="position: absolute;">Tutorial</button>
</header>

<video src="../video_ragazza.mp4" muted loop autoplay></video>
<div class="overlay"></div>
<div class="text">
    <p>Soundbuddy è un sito progettato per consigliarti la musica migliore per TE, in funzione del tuo umore, tutto questo con un solo click</p>
    <h2>LE TUE SENSAZIONI LA NOSTRA PREOCCUPAZIONE</h2>
</div>
<div class="box">
    </br>
    <h1>Come ti senti?</h1>
    <button class="filtrare">Come filtrare la tua emozione</button>
    <button class="cercare">Come cercare la tua emozione</buttom>
    <button class="scegliere">Come scegliere la tua emozione</button>
    <h3 class="filtra">Filtra</h3>
    <h3 class="movimento" style="display: none;">Filtra le tue emozioni</h3>
    <button id="bottone_1" class="movimento" style="display: none;">Positive</button>
    <button id="bottone_2" class="movimento" style="display: none;">Negative</button>
    <button id="reset">reset</button>
    <input type="text" id="cerca" name="emozioni" placeholder="Inserisci..." size="30" maxlength="30">
    <input type="submit" name="" value="Start" onclick="cerca()">
    <ul id="lista" style="list-style-type:none;">
    </br>
    <h2>Emozioni</h2>
    <div id="positive">
        <h3>Positive</h3>
            <a href="Felicita/felicita.html"><li>Felicità</li></a>
            <a href="Serenita/serenita.html"><li>Serenità</li></a>
    </div>
    <div id="negative">
        <h3>Negative</h3>
            <a href="Tristezza/tristezza.html"><li>Tristezza</li></a>
            <a href="Paura/paura.html"><li>Paura</li></a>
    </div>
    </ul>
</div>

<script src="../script.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>

</html>
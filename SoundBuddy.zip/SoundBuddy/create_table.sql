CREATE TABLE utente (
    username varchar(40),
    email varchar(40) UNIQUE, 
    paswd varchar(255) not null,
    domanda varchar(40),
    paswd_dimenticata varchar(255) not null,
    PRIMARY KEY (email),
    UNIQUE (username)
);
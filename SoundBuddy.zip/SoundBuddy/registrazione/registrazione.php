<!--
    script php che permette la registrazione dell'utente attraverso l'utilizzo di postgreSQL con l'utilizzo di un database
-->

<?php
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: /");
}
else {
    $dbconn = pg_connect("host= port= dbname=
    user= password=") 
                or die('Could not connect: ' . pg_last_error());
}
?>
<!DOCTYPE html>
<html>
    <head></head>
    <body>
        <?php
            if ($dbconn) {
                $email = $_POST['inputEmail'];
                $q1="select * from utente where email= $1";
                $result=pg_query_params($dbconn, $q1, array($email));
                if ($tuple=pg_fetch_array($result, null, PGSQL_ASSOC)) {
                    header("Location: ../index.html");
                }
                else {
                    $username = $_POST['inputUsername'];
                    $q2 = "select * from utente where username = $1";
                    $result = pg_query_params($dbconn, $q2, array($username));
                    
                    if (!($tuple = pg_fetch_array($result, null, PGSQL_ASSOC))) {
                        $password = password_hash($_POST['inputPassword'], PASSWORD_DEFAULT);
                        $domanda = $_POST['domanda'];
                        $password_dimenticata = password_hash($_POST['inputPasswordDimenticata'], PASSWORD_DEFAULT);
                        
                        $q3 = "insert into utente values ($1,$2,$3,$4,$5)";
                        $data = pg_query_params($dbconn, $q3,
                            array($username, $email, $password, $domanda, $password_dimenticata));
                        
                        if ($data) {
                            header("Location: ../index2.html");
                        }
                    } 
                    else {
                        header("Location: ../index7.html");
                    }
                }
            }
        ?> 
    </body>
</html>
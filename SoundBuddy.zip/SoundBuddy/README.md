


Soundbuddy.html->rappresenta la pagina iniziale dove si può effettuare il login/registrazione e la password dimenticata, in questo file, viene utilizzato tra le altre cose bootstrap e javascript.


Index.html
Index2.html
Index3.html
Index4.html        -> Reindirizzamento a una pagina differente dovuta a un errore da parte dell'utente durante il login/registrazione/password dimenticata
Index5.html
Index6.html
Index7.html
Index8.html


About.html.   pagina appartenente alla navbar iniziale che si occupa di dare un plus di informazioni sul sito 


Servizi.html   pagina appartenente alla navbar iniziale che ha il compito di fornire informazioni sui servizi dell' applicazione web

Contatti.html.  pagina appartenente alla navbar iniziale che ha il compito di fornire informazioni su chi ha sviluppato il progetto SoundBuddy

Registrazione.php. script php che permette la registrazione dell'utente attraverso l'utilizzo di postgreSQL con l'utilizzo di un database

create_table.sql. file che si occupa della creazione della tabella utente nel database 

Script.js.    file javascript dove vengono gestite le funzioni delle pagine html implementate con il linguaggio js

Stili.css.    pagina dedicata agli stili grafici delle pagine html principali dell'applicazione web

/login/app.js  file javascript dove viene gestita la playlist i collegamenti ipertestuali delle canzoni youtube 

/login/login.php     script php che permette il login dell'utente attraverso l'utilizzo di postgreSQL con l'utilizzo di un database

/login/logout.php     script php che permette il logout dell'utente attraverso l'utilizzo di postgreSQL con l'utilizzo di un database

/login/password_dimenticata.php     script php che permette il reset della password dell'utente attraverso l'utilizzo di postgreSQL con l'utilizzo di un database

/login/welcome.php      script php/html che gestisce l'homepage dell'applicazione web ove è presente la playlist musicale, la barra di ricerca,
    tutte le emozioni da filtrare e il tutorial

/login/password_dimenticata.html.   pagina che gestisce il lato di layout del reset della password

/login/Amicizia/Amicizia.php.  pagina riguardante un'emozione rappresentanta da 10 scelte musicali(video youtube) e i rispettivi testi(genius)

/login/Amicizia/musica_1.html   Video musicale(YouTube)

/login/Amicizia/testo_1.html.   testo di musica_1 preso da genius

/login/Amicizia/stile_friendship.css. pagina dedicata agli stili grafici dell'emozione





Per i file non commentati che riguardano le varie emozioni abbiamo utilizzato lo stesso modus operandi della parte della amicizia per evitare ripetizioni di vario genere si veda Amicizia.php/musica_1.html/testo_1.html e stile_friendship.css

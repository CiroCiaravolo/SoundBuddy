let app = Vue.createApp({
    data() {
        return {
            isEditing: false,
            selectedIndex: null,
            music: '',
            all: [],
            musicLink: {
                "Macarena": 'musica_1.html', "Don't Stop Me Now": 'musica_2.html', 
                "Good Vibrations": 'musica_3.html', "Bailando": 'musica_4.html', 
                "Mon Amour": 'musica_5.html', "Giovani Wannabe": 'musica_6.html', 
                "Fantastica": 'musica_7.html', "Wake Me Up": 'musica_8.html', 
                "I Don't Care": 'musica_9.html', "Somebody To You": 'musica_10.html',
                "Macarena": '/SoundBuddy/login/Divertimento/musica_1.html', "Don't Stop Me Now": '/SoundBuddy/login/Divertimento/musica_2.html', 
                "Good Vibrations": '/SoundBuddy/login/Divertimento/musica_3.html', "Bailando": '/SoundBuddy/login/Divertimento/musica_4.html', 
                "Mon Amour": '/SoundBuddy/login/Divertimento/musica_5.html', "Giovani Wannabe": '/SoundBuddy/login/Divertimento/musica_6.html', 
                "Fantastica": '/SoundBuddy/login/Divertimento/musica_7.html', "Wake Me Up": '/SoundBuddy/login/Divertimento/musica_8.html', 
                "I Don't Care": '/SoundBuddy/login/Divertimento/musica_9.html', "Somebody To You": '/SoundBuddy/login/Divertimento/musica_10.html',
                "I Wanna Be Yours": 'musica_1.html', "Per sentirmi vivo": 'musica_2.html', 
                "Brividi": 'musica_3.html', "A L I": 'musica_4.html', 
                "Say You Won't Let Go": 'musica_5.html', "Someone You Loved": 'musica_6.html', 
                "Love Yourself": 'musica_7.html', "Can I Be Him": 'musica_8.html', 
                "Another Love": 'musica_9.html', "Girasoli": 'musica_10.html',
                "I Wanna Be Yours": '/SoundBuddy/login/Solitudine/musica_1.html', "Per sentirmi vivo": '/SoundBuddy/login/Solitudine/musica_2.html', 
                "Brividi": '/SoundBuddy/login/Solitudine/musica_3.html', "A L I": '/SoundBuddy/login/Solitudine/musica_4.html', 
                "Say You Won't Let Go": '/SoundBuddy/login/Solitudine/musica_5.html', "Someone You Loved": '/SoundBuddy/login/Solitudine/musica_6.html', 
                "Love Yourself": '/SoundBuddy/login/Solitudine/musica_7.html', "Can I Be Him": '/SoundBuddy/login/Solitudine/musica_8.html', 
                "Another Love": '/SoundBuddy/login/Solitudine/musica_9.html', "Girasoli": '/SoundBuddy/login/Solitudine/musica_10.html',
                "Ne è Valsa la pena": 'musica_1.html', "Bro + Bro": 'musica_2.html', 
                "Mezza Siga": 'musica_3.html', "Wild Bandana": 'musica_4.html', 
                "Mon Fre": 'musica_5.html', "Hotel Lobby": 'musica_6.html', 
                "Mai Brillo": 'musica_7.html', "Ulala": 'musica_8.html', 
                "Oh mama": 'musica_9.html', "Se rinasco": 'musica_10.html',
                "Ne è Valsa la pena": '/SoundBuddy/login/Amicizia/musica_1.html', "Bro + Bro": '/SoundBuddy/login/Amicizia/musica_2.html', 
                "Mezza Siga": '/SoundBuddy/login/Amicizia/musica_3.html', "Wild Bandana": '/SoundBuddy/login/Amicizia/musica_4.html', 
                "Mon Fre": '/SoundBuddy/login/Amicizia/musica_5.html', "Hotel Lobby": '/SoundBuddy/login/Amicizia/musica_6.html', 
                "Mai Brillo": '/SoundBuddy/login/Amicizia/musica_7.html', "Ulala": '/SoundBuddy/login/Amicizia/musica_8.html', 
                "Oh mama": '/SoundBuddy/login/Amicizia/musica_9.html', "Se rinasco": '/SoundBuddy/login/Amicizia/musica_10.html',
                "Scuol4": 'musica_1.html', "Ulisse": 'musica_2.html', 
                "Vita Sbagliata": 'musica_3.html', "The race": 'musica_4.html', 
                "Bullet From A Gun": 'musica_5.html', "Ti ricordi?": 'musica_6.html', 
                "Disoriental Express": 'musica_7.html', "Solite pare": 'musica_8.html', 
                "Day 'N' Nite": 'musica_9.html', "Mama": 'musica_10.html',
                "Scuol4": '/SoundBuddy/login/Ansia/musica_1.html', "Ulisse": '/SoundBuddy/login/Ansia/musica_2.html', 
                "Vita Sbagliata": '/SoundBuddy/login/Ansia/musica_3.html', "The race": '/SoundBuddy/login/Ansia/musica_4.html', 
                "Bullet From A Gun": '/SoundBuddy/login/Ansia/musica_5.html', "Ti ricordi?": '/SoundBuddy/login/Ansia/musica_6.html', 
                "Disoriental Express": '/SoundBuddy/login/Ansia/musica_7.html', "Solite pare": '/SoundBuddy/login/Ansia/musica_8.html', 
                "Day 'N' Nite": '/SoundBuddy/login/Ansia/musica_9.html', "Mama": '/SoundBuddy/login/Ansia/musica_10.html',
                "Ande": 'musica_1.html', "God's Plan": 'musica_2.html', 
                "Feels like Summer": 'musica_3.html', "Sunflower": 'musica_4.html', 
                "intro Honestly Nevermind": 'musica_5.html', "Money Trees": 'musica_6.html', 
                "Jappone": 'musica_7.html', "Gangstar of Love": 'musica_8.html', 
                "Sandra's Rose": 'musica_9.html', "Father Stretch My Hands Pt. 1": 'musica_10.html',
                "Ande": '/SoundBuddy/login/Chill/musica_1.html', "God's Plan": '/SoundBuddy/login/Chill/musica_2.html', 
                "Feels like Summer": '/SoundBuddy/login/Chill/musica_3.html', "Sunflower": '/SoundBuddy/login/Chill/musica_4.html', 
                "intro Honestly Nevermind": '/SoundBuddy/login/Chill/musica_5.html', "Money Trees": '/SoundBuddy/login/Chill/musica_6.html', 
                "Jappone": '/SoundBuddy/login/Chill/musica_7.html', "Gangstar of Love": '/SoundBuddy/login/Chill/musica_8.html', 
                "Sandra's Rose": '/SoundBuddy/login/Chill/musica_9.html', "Father Stretch My Hands Pt. 1": '/SoundBuddy/login/Chill/musica_10.html',
                "Happy": 'musica_1.html', "We Are One": 'musica_2.html', 
                "Love Generation": 'musica_3.html', "Ballo del Blocco": 'musica_4.html', 
                "Young Wild and Free": 'musica_5.html', "THRIFT SHOP": 'musica_6.html', 
                "All Star": 'musica_7.html', "Come mai": 'musica_8.html', 
                "Over the Rainbow RMX": 'musica_9.html', "Estate": 'musica_10.html',
                "Happy": '/SoundBuddy/login/Felicita/musica_1.html', "We Are One": '/SoundBuddy/login/Felicita/musica_2.html', 
                "Love Generation": '/SoundBuddy/login/Felicita/musica_3.html', "Ballo del Blocco": '/SoundBuddy/login/Felicita/musica_4.html', 
                "Young Wild and Free": '/SoundBuddy/login/Felicita/musica_5.html', "THRIFT SHOP": '/SoundBuddy/login/Felicita/musica_6.html', 
                "All Star": '/SoundBuddy/login/Felicita/musica_7.html', "Come mai": '/SoundBuddy/login/Felicita/musica_8.html', 
                "Over the Rainbow RMX": '/SoundBuddy/login/Felicita/musica_9.html', "Estate": '/SoundBuddy/login/Felicita/musica_10.html',
                "Non Abbiamo eta": 'musica_1.html', "Ti amo": 'musica_2.html', 
                "La Musica non c'è": 'musica_3.html', "Tango": 'musica_4.html', 
                "Tu Te scurdat e me": 'musica_5.html', "Ti Amo": 'musica_6.html', 
                "I Want It That Way": 'musica_7.html', "I love you Baby": 'musica_8.html', 
                "Sarà perchè ti amo": 'musica_9.html', "M'manc": 'musica_10.html',
                "Non Abbiamo eta": '/SoundBuddy/login/Innamorato/musica_1.html', "Ti amo": '/SoundBuddy/login/Innamorato/musica_2.html', 
                "La Musica non c'è": '/SoundBuddy/login/Innamorato/musica_3.html', "Tango": '/SoundBuddy/login/Innamorato/musica_4.html', 
                "Tu Te scurdat e me": '/SoundBuddy/login/Innamorato/musica_5.html', "Ti Amo": '/SoundBuddy/login/Innamorato/musica_6.html', 
                "I Want It That Way": '/SoundBuddy/login/Innamorato/musica_7.html', "I love you Baby": '/SoundBuddy/login/Innamorato/musica_8.html', 
                "Sarà perchè ti amo": '/SoundBuddy/login/Innamorato/musica_9.html', "M'manc": '/SoundBuddy/login/Innamorato/musica_10.html',
                "Thriller": 'musica_1.html', "Scooby Doo Gang": 'musica_2.html', 
                "Violent Crimes": 'musica_3.html', "Una Chiave": 'musica_4.html', 
                "Butterfly Knife": 'musica_5.html', "Babushka Boi": 'musica_6.html', 
                "Love Sosa": 'musica_7.html', "Roulette Russa": 'musica_8.html', 
                "Perfect Girl": 'musica_9.html', "After Dark": 'musica_10.html',
                "Thriller": '/SoundBuddy/login/Paura/musica_1.html', "Scooby Doo Gang": '/SoundBuddy/login/Paura/musica_2.html', 
                "Violent Crimes": '/SoundBuddy/login/Paura/musica_3.html', "Una Chiave": '/SoundBuddy/login/Paura/musica_4.html', 
                "Butterfly Knife": '/SoundBuddy/login/Paura/musica_5.html', "Babushka Boi": '/SoundBuddy/login/Paura/musica_6.html', 
                "Love Sosa": '/SoundBuddy/login/Paura/musica_7.html', "Roulette Russa": '/SoundBuddy/login/Paura/musica_8.html', 
                "Perfect Girl": '/SoundBuddy/login/Paura/musica_9.html', "After Dark": '/SoundBuddy/login/Paura/musica_10.html',
                "Sabbie d'oro": 'musica_1.html', "Yes Indeed": 'musica_2.html', 
                "Jimmy Cooks": 'musica_3.html', "Cavalcata delle Valchirie": 'musica_4.html', 
                "Salsa": 'musica_5.html', "Whatever It Takes": 'musica_6.html', 
                "Slang": 'musica_7.html', "Big Poppa": 'musica_8.html', 
                "XDVRMX": 'musica_9.html', "F.N": 'musica_10.html',
                "Sabbie d'oro": '/SoundBuddy/login/Rabbia/musica_1.html', "Yes Indeed": '/SoundBuddy/login/Rabbia/musica_2.html', 
                "Jimmy Cooks": '/SoundBuddy/login/Rabbia/musica_3.html', "Cavalcata delle Valchirie": '/SoundBuddy/login/Rabbia/musica_4.html', 
                "Salsa": '/SoundBuddy/login/Rabbia/musica_5.html', "Whatever It Takes": '/SoundBuddy/login/Rabbia/musica_6.html', 
                "Slang": '/SoundBuddy/login/Rabbia/musica_7.html', "Big Poppa": '/SoundBuddy/login/Rabbia/musica_8.html', 
                "XDVRMX": '/SoundBuddy/login/Rabbia/musica_9.html', "F.N": '/SoundBuddy/login/Rabbia/musica_10.html',
                "Hello": 'musica_1.html', "Heat Waves": 'musica_2.html', 
                "Ancora sveglio": 'musica_3.html', "Nastro Rosa": 'musica_4.html', 
                "Lucid Dream": 'musica_5.html', "Falling": 'musica_6.html', 
                "Bella": 'musica_7.html', "Summertime Sadness": 'musica_8.html', 
                "True Love": 'musica_9.html', "Crudelia": 'musica_10.html',
                "Hello": '/SoundBuddy/login/Tristezza/musica_1.html', "Heat Waves": '/SoundBuddy/login/Tristezza/musica_2.html', 
                "Ancora sveglio": '/SoundBuddy/login/Tristezza/musica_3.html', "Nastro Rosa": '/SoundBuddy/login/Tristezza/musica_4.html', 
                "Lucid Dream": '/SoundBuddy/login/Tristezza/musica_5.html', "Falling": '/SoundBuddy/login/Tristezza/musica_6.html', 
                "Bella": '/SoundBuddy/login/Tristezza/musica_7.html', "Summertime Sadness": '/SoundBuddy/login/Tristezza/musica_8.html', 
                "True Love": '/SoundBuddy/login/Tristezza/musica_9.html', "Crudelia": '/SoundBuddy/login/Tristezza/musica_10.html'
            }
        }
    },
    created() {
        const storageUsername = 'vue-music-storage-' + username;
        this.all = JSON.parse(localStorage.getItem(storageUsername) || '[]');
    },
    methods: {
        allMusic: function() {
            this.all.push(this.music)
            this.music =''
            this.save();
        },
        editMusic: function(index, music) {
            this.music = music
            this.selectedIndex = index
            this.isEditing = true
        },
        updateMusic: function(){
            this.all.splice(this.selectedIndex, 1, this.music)
            this.isEditing = false
            this.save();
        },
        deleteMusic: function(index) {
            this.all.splice(index, 1)
            this.save();
        },
        reset: function() {
            const storageUsername = 'vue-music-storage-' + username;
            localStorage.removeItem(storageUsername);
            this.all = [];
        },
        save: function() {
            const storageUsername = 'vue-music-storage-' + username;
            localStorage.setItem(storageUsername, JSON.stringify(this.all));
        }
    }
});
app.mount('#app');
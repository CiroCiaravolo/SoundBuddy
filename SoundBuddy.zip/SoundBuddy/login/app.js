/*
file javascript dove viene gestita la playlist i collegamenti ipertestuali delle canzoni youtube 
*/

let app = Vue.createApp({
    data() {
        return {
            isEditing: false,
            selectedIndex: null,
            music: '',
            all: [],
            musicLink: {
                
                "Macarena": 'Divertimento/musica_1.html', "Don't Stop Me Now": 'Divertimento/musica_2.html', 
                "Good Vibrations": 'Divertimento/musica_3.html', "Bailando": 'Divertimento/musica_4.html', 
                "Mon Amour": 'Divertimento/musica_5.html', "Giovani Wannabe": 'Divertimento/musica_6.html', 
                "Fantastica": 'Divertimento/musica_7.html', "Wake Me Up": 'Divertimento/musica_8.html', 
                "I Don't Care": 'Divertimento/musica_9.html', "Somebody To You": 'Divertimento/musica_10.html',
              
                "I Wanna Be Yours": 'Solitudine/musica_1.html', "Per sentirmi vivo": 'Solitudine/musica_2.html', 
                "Brividi": 'Solitudine/musica_3.html', "A L I": 'Solitudine/musica_4.html', 
                "Say You Won't Let Go": 'Solitudine/musica_5.html', "Someone You Loved": 'Solitudine/musica_6.html', 
                "Love Yourself": 'Solitudine/musica_7.html', "Can I Be Him": 'Solitudine/musica_8.html', 
                "Another Love": 'Solitudine/musica_9.html', "Girasoli": 'Solitudine/musica_10.html',
                
                "Ne è Valsa la pena": 'Amicizia/musica_1.html', "Bro + Bro": 'Amicizia/musica_2.html', 
                "Mezza Siga": 'Amicizia/musica_3.html', "Wild Bandana": 'Amicizia/musica_4.html', 
                "Mon Fre": 'Amicizia/musica_5.html', "Hotel Lobby": 'Amicizia/musica_6.html', 
                "Mai Brillo": 'Amicizia/musica_7.html', "Ulala": 'Amicizia/musica_8.html', 
                "Oh mama": 'Amicizia/musica_9.html', "Se rinasco": 'Amicizia/musica_10.html',
                
                "Scuol4": 'Ansia/musica_1.html', "Ulisse": 'Ansia/musica_2.html', 
                "Vita Sbagliata": 'Ansia/musica_3.html', "The race": 'Ansia/musica_4.html', 
                "Bullet From A Gun": 'Ansia/musica_5.html', "Ti ricordi?": 'Ansia/musica_6.html', 
                "Disoriental Express": 'Ansia/musica_7.html', "Solite pare": 'Ansia/musica_8.html', 
                "Day 'N' Nite": 'Ansia/musica_9.html', "Mama": 'Ansia/musica_10.html',
              
                "Ande": 'Chill/musica_1.html', "God's Plan": 'Chill/musica_2.html', 
                "Feels like Summer": 'Chill/musica_3.html', "Sunflower": 'Chill/musica_4.html', 
                "intro Honestly Nevermind": 'Chill/musica_5.html', "Money Trees": 'Chill/musica_6.html', 
                "Jappone": 'Chill/musica_7.html', "Gangstar of Love": 'Chill/musica_8.html', 
                "Sandra's Rose": 'Chill/musica_9.html', "Father Stretch My Hands Pt. 1": 'Chill/musica_10.html',
                
                "Happy": 'Felicita/musica_1.html', "We Are One": 'Felicita/musica_2.html', 
                "Love Generation": 'Felicita/musica_3.html', "Ballo del Blocco": 'Felicita/musica_4.html', 
                "Young Wild and Free": 'Felicita/musica_5.html', "THRIFT SHOP": 'Felicita/musica_6.html', 
                "All Star": 'Felicita/musica_7.html', "Come mai": 'Felicita/musica_8.html', 
                "Over the Rainbow RMX": 'Felicita/musica_9.html', "Estate": 'Felicita/musica_10.html',
                
                "Non Abbiamo eta": 'Innamorato/musica_1.html', "Ti amo": 'Innamorato/musica_2.html', 
                "La Musica non c'è": 'Innamorato/musica_3.html', "Tango": 'Innamorato/musica_4.html', 
                "Tu Te scurdat e m": 'Innamorato/musica_5.html', "Ti Amo": 'Innamorato/musica_6.html', 
                "I Want It That Way": 'Innamorato/musica_7.html', "I love you Baby": 'Innamorato/musica_8.html', 
                "Sarà perchè ti amo": 'Innamorato/musica_9.html', "M'manc": 'Innamorato/musica_10.html',
               
                "Thriller": 'Paura/musica_1.html', "Scooby Doo Gang": 'Paura/musica_2.html', 
                "Violent Crimes": 'Paura/musica_3.html', "Una Chiave": 'Paura/musica_4.html', 
                "Butterfly Knife": 'Paura/musica_5.html', "Babushka Boi": 'Paura/musica_6.html', 
                "Love Sosa": 'Paura/musica_7.html', "Roulette Russa": 'Paura/musica_8.html', 
                "Perfect Girl": 'Paura/musica_9.html', "After Dark": 'Paura/musica_10.html',
               
                "Sabbie d'oro": 'Rabbia/musica_1.html', "Yes Indeed": 'Rabbia/musica_2.html', 
                "Jimmy Cooks": 'Rabbia/musica_3.html', "Cavalcata delle Valchirie": 'Rabbia/musica_4.html', 
                "Salsa": 'Rabbia/musica_5.html', "Whatever It Takes": 'Rabbia/musica_6.html', 
                "Slang": 'Rabbia/musica_7.html', "Big Poppa": 'Rabbia/musica_8.html', 
                "XDVRMX": 'Rabbia/musica_9.html', "F.N": 'Rabbia/musica_10.html',
                
                "Hello": 'Tristezza/musica_1.html', "Heat Waves": 'Tristezza/musica_2.html', 
                "Ancora sveglio": 'Tristezza/musica_3.html', "Nastro Rosa": 'Tristezza/musica_4.html', 
                "Lucid Dream": 'Tristezza/musica_5.html', "Falling": 'Tristezza/musica_6.html', 
                "Bella": 'Tristezza/musica_7.html', "Summertime Sadness": 'Tristezza/musica_8.html', 
                "True Love": 'Tristezza/musica_9.html', "Crudelia": 'Tristezza/musica_10.html'
            }
        }
    },
    created() {
        const storageUsername = 'vue-music-storage-' + username;
        this.all = JSON.parse(localStorage.getItem(storageUsername) || '[]');
    },
    methods: {
        allMusic: function() {
            this.all.push(this.music)
            this.music =''
            this.save();
        },
        editMusic: function(index, music) {
            this.music = music
            this.selectedIndex = index
            this.isEditing = true
        },
        updateMusic: function(){
            this.all.splice(this.selectedIndex, 1, this.music)
            this.isEditing = false
            this.save();
        },
        deleteMusic: function(index) {
            this.all.splice(index, 1)
            this.save();
        },
        reset: function() {
            const storageUsername = 'vue-music-storage-' + username;
            localStorage.removeItem(storageUsername);
            this.all = [];
        },
        save: function() {
            const storageUsername = 'vue-music-storage-' + username;
            localStorage.setItem(storageUsername, JSON.stringify(this.all));
        }
    }
});
app.mount('#app');
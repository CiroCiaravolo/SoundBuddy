const STORAGE = 'vue-music-storage';
let app = Vue.createApp({
    data() {
        return {
            isEditing: false,
            selectedIndex: null,
            music: '',
            all: []
        }
    },
    created() {
        this.all = JSON.parse(localStorage.getItem(STORAGE) || '[]');
    },
    methods: {
        allMusic: function() {
            this.all.push(this.music)
            this.music =''
            localStorage.setItem(STORAGE, JSON.stringify(this.all));
        },
        editMusic: function(index, music) {
            this.music = music
            this.selectedIndex = index
            this.isEditing = true
        },
        updateMusic: function(){
            this.all.splice(this.selectedIndex, 1, this.music)
            this.isEditing = false
            localStorage.setItem(STORAGE, JSON.stringify(this.all));
        },
        deleteMusic: function(index) {
            this.all.splice(index, 1)
            localStorage.setItem(STORAGE, JSON.stringify(this.all));
        },
        reset: function() {
            localStorage.clear();
        }
    }
});
app.mount('#app');
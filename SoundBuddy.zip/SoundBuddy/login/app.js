let app = Vue.createApp({
    data() {
        return {
            isEditing: false,
            selectedIndex: null,
            music: '',
            all: [],
            musicLink: {
                "Macarena": 'musica_1.html', "Don't Stop Me Now": 'musica_2.html', 
                "Good Vibrations": 'musica_3.html', "Bailando": 'musica_4.html', 
                "Mon Amour": 'musica_5.html', "Giovani Wannabe": 'musica_6.html', 
                "Fantastica": 'musica_7.html', "Wake Me Up": 'musica_8.html', 
                "I Don't Care": 'musica_9.html', "Somebody To You": 'musica_10.html',
                "Macarena": '/SoundBuddy/login/Divertimento/musica_1.html', "Don't Stop Me Now": '/SoundBuddy/login/Divertimento/musica_2.html', 
                "Good Vibrations": '/SoundBuddy/login/Divertimento/musica_3.html', "Bailando": '/SoundBuddy/login/Divertimento/musica_4.html', 
                "Mon Amour": '/SoundBuddy/login/Divertimento/musica_5.html', "Giovani Wannabe": '/SoundBuddy/login/Divertimento/musica_6.html', 
                "Fantastica": '/SoundBuddy/login/Divertimento/musica_7.html', "Wake Me Up": '/SoundBuddy/login/Divertimento/musica_8.html', 
                "I Don't Care": '/SoundBuddy/login/Divertimento/musica_9.html', "Somebody To You": '/SoundBuddy/login/Divertimento/musica_10.html',
                "I Wanna Be Yours": 'musica_1.html', "Per sentirmi vivo": 'musica_2.html', 
                "Brividi": 'musica_3.html', "A L I": 'musica_4.html', 
                "Say You Won't Let Go": 'musica_5.html', "Someone You Loved": 'musica_6.html', 
                "Love Yourself": 'musica_7.html', "Can I Be Him": 'musica_8.html', 
                "Another Love": 'musica_9.html', "Girasoli": 'musica_10.html',
                "I Wanna Be Yours": '/SoundBuddy/login/Solitudine/musica_1.html', "Per sentirmi vivo": '/SoundBuddy/login/Solitudine/musica_2.html', 
                "Brividi": '/SoundBuddy/login/Solitudine/musica_3.html', "A L I": '/SoundBuddy/login/Solitudine/musica_4.html', 
                "Say You Won't Let Go": '/SoundBuddy/login/Solitudine/musica_5.html', "Someone You Loved": '/SoundBuddy/login/Solitudine/musica_6.html', 
                "Love Yourself": '/SoundBuddy/login/Solitudine/musica_7.html', "Can I Be Him": '/SoundBuddy/login/Solitudine/musica_8.html', 
                "Another Love": '/SoundBuddy/login/Solitudine/musica_9.html', "Girasoli": '/SoundBuddy/login/Solitudine/musica_10.html'
  
            }
        }
    },
    created() {
        const storageUsername = 'vue-music-storage-' + username;
        this.all = JSON.parse(localStorage.getItem(storageUsername) || '[]');
    },
    methods: {
        allMusic: function() {
            this.all.push(this.music)
            this.music =''
            this.save();
        },
        editMusic: function(index, music) {
            this.music = music
            this.selectedIndex = index
            this.isEditing = true
        },
        updateMusic: function(){
            this.all.splice(this.selectedIndex, 1, this.music)
            this.isEditing = false
            this.save();
        },
        deleteMusic: function(index) {
            this.all.splice(index, 1)
            this.save();
        },
        reset: function() {
            const storageUsername = 'vue-music-storage-' + username;
            localStorage.removeItem(storageUsername);
            this.all = [];
        },
        save: function() {
            const storageUsername = 'vue-music-storage-' + username;
            localStorage.setItem(storageUsername, JSON.stringify(this.all));
        }
    }
});
app.mount('#app');
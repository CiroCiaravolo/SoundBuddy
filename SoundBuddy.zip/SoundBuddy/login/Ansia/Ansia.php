<!DOCTYPE HTML>
<html>

<head>
  <title>Ansia</title>
  <link rel="stylesheet" href="stile_ansia.css">
  <script src="https://unpkg.com/vue@3"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">


</head>
<body background="../Ansia/ansia.jpg">
<?php
    session_start();
    if (isset($_SESSION['username'])) {
      $username = $_SESSION['username'];
      echo "<script>const username = '$username';</script>";
    }
  ?>
<a href="../welcome.php">Back</a>
  <h1>L'ansia è negativa solo se non sappiamo come sfruttarla
  </h1>
  <div id='app'>
  <span class="musica" onmouseover="caricaDocumento(event)">musica_1</span> <input type="checkbox" id="musica_1" value="Scuol4" class="star" v-model="all" @change="save">
  <label for="musica_1"></label>
  <span class="musica" onmouseover="caricaDocumento(event)">musica_2</span> <input type="checkbox" id="musica_2" value="Ulisse" class="star" v-model="all" @change="save">
  <label for="musica_2"></label>
  <span class="musica" onmouseover="caricaDocumento(event)">musica_3</span> <input type="checkbox" id="musica_3" value="Vita Sbagliata" class="star" v-model="all" @change="save">
  <label for="musica_3"></label>
  <span class="musica" onmouseover="caricaDocumento(event)">musica_4</span> <input type="checkbox" id="musica_4" value="The race" class="star" v-model="all" @change="save">
  <label for="musica_4"></label>
  <span class="musica" onmouseover="caricaDocumento(event)">musica_5</span> <input type="checkbox" id="musica_5" value="Bullet From A Gun" class="star" v-model="all" @change="save">
  <label for="musica_5"></label>
  <span class="musica" onmouseover="caricaDocumento(event)">musica_6</span> <input type="checkbox" id="musica_6" value="Ti ricordi?" class="star" v-model="all" @change="save">
  <label for="musica_6"></label>
  <span class="musica" onmouseover="caricaDocumento(event)">musica_7</span> <input type="checkbox" id="musica_7" value="Disoriental Express" class="star" v-model="all" @change="save">
  <label for="musica_7"></label>
  <span class="musica" onmouseover="caricaDocumento(event)">musica_8</span> <input type="checkbox" id="musica_8" value="Solite pare" class="star" v-model="all" @change="save">
  <label for="musica_8"></label>
  <span class="musica" onmouseover="caricaDocumento(event)">musica_9</span> <input type="checkbox" id="musica_9" value="Day 'N' Nite" class="star" v-model="all" @change="save">
  <label for="musica_9"></label>
  <span class="musica" onmouseover="caricaDocumento(event)">musica_10</span> <input type="checkbox" id="musica_10" value="Mama" class="star" v-model="all" @change="save">
  <label for="musica_10"></label>
  <br />
  <span class="testo" onmouseover="caricaDocumento(event)">testo_1</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_2</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_3</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_4</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_5</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_6</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_7</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_8</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_9</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_10</span>
  </div>
  <hr />
  <div id="zona_musica">
    Musica
  </div>
  <hr />
  <div id="zona_testo">
    Testo
  </div>
  <hr />
  <script>
    function caricaDocumento(e) {
      var httpRequest = new XMLHttpRequest();
      httpRequest.prevTarget = e.target;
      httpRequest.onreadystatechange = gestisciResponse;
      httpRequest.open("GET", e.target.innerHTML + ".html", true);
      httpRequest.send();
    }
    function gestisciResponse(e) {
      if (e.target.readyState == 4 && e.target.status == 200) {
        document.getElementById("zona_" +
          e.target.prevTarget.getAttribute("class")).innerHTML =
          e.target.responseText;
      }
    } 
  </script>
</body>
<script src="../app.js"></script>
</html>
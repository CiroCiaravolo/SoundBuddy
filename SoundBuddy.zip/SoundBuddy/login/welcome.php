<html lang="it"></html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatibile" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> SuondBuddy</title>
    <link rel="stylesheet" href="../stili.css" >
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://unpkg.com/vue@3"></script>
    <script>
    $(document).ready(function(){
        $("#bottone_1").click(function(){
        $("#negative").detach();
        $("#positive").css("color", "red");
        });
        $("#bottone_2").click(function(){
        $("#positive").detach();
        $("#negative").css("color", "red");
        });
        $("#bottone_3").click(function() {
        location.reload();
        });
    });
    $(document).ready(function () {
      $(".filtrare").click(function () {
        $("#tutorial").animate({ top: '134%' });
      });
      $(".filtrare").mouseleave(function () {
        $("#tutorial").fadeOut();
      });
      $(".filtrare").mouseenter(function () {
        $("#tutorial").fadeIn();
      });
      $(".cercare").click(function () {
        $("#tutorial").animate({ top: '158%' });
      });
      $(".cercare").mouseleave(function () {
        $("#tutorial").fadeOut();
      });
      $(".cercare").mouseenter(function () {
        $("#tutorial").fadeIn();
      });
      $(".scegliere").click(function () {
        $("#tutorial").animate({ top: '184%' });
      });
      $(".scegliere").mouseleave(function () {
        $("#tutorial").fadeOut();
      });
      $(".scegliere").mouseenter(function () {
        $("#tutorial").fadeIn();
      });
      $(".filtra").click(function () {
        $(".movimento").slideToggle();
      });
    });
    </script>
    </head>

    <body>
        <header>
        <p class="welcome-message">
        <?php
            $username=$_GET['username'];
            echo "Welcome $username";
        ?>
        </p>
        <img src="../logo.jpg.png"/>
        <nav class="navigation">
        <div id = "app">
            <form action="logout.php" class="form-signin m-auto" 
                method="POST" name="myForm">
                
                <button type="submit" class="btn" @click="reset">LogOut</button>
            </form>
            <h1>Music</h1>

            <div v-if="!isEditing">
                <input type="text" v-model="music">
                <input type="submit" value="add" @click="allMusic">
            </div>
            <div v-else>
                <input type="text" v-model="music">
                <input type="submit" value="update" @click="updateMusic">
            </div>
            <ol>
                <li v-for="(music, index) in all">
                    {{ music }}
                    <button @click="editMusic(index, music)">Edit</button>
                    <button @click="deleteMusic(index)">Delete</button>
                </li>
            </ol>
</div>
        </nav>  
        <button id="tutorial" style="position: absolute;">Tutorial</button>
</header>

<video src="../video_ragazza.mp4" muted loop autoplay></video>
<div class="overlay"></div>
<div class="text">
    <p>Soundbuddy è un sito progettato per consigliarti la musica migliore per TE, in funzione del tuo umore, tutto questo con un solo click</p>
    <h2>LE TUE SENSAZIONI LA NOSTRA PREOCCUPAZIONE</h2>
</div>
<div class="box">
    </br>
    <h1>Come ti senti?</h1>
    <button class="filtrare">Come filtrare la tua emozione</button>
    <button class="cercare">Come cercare la tua emozione</buttom>
    <button class="scegliere">Come scegliere la tua emozione</button>
    <h3 class="filtra">Filtra</h3>
    <h3 class="movimento" style="display: none;">Filtra le tue emozioni</h3>
    <button id="bottone_1" class="movimento" style="display: none;">Positive</button>
    <button id="bottone_2" class="movimento" style="display: none;">Negative</button>
    <button id="bottone_3" class="movimento" style="display: none;">Reset</button>
    <input type="text" id="cerca" name="emozioni" placeholder="Inserisci..." size="30" maxlength="30" onkeyup="cerca()">
    <input type="submit" name="" value="Start">
    <ul id="lista" style="list-style-type:none;">
    </br>
    <h2>Emozioni</h2>
    <div id="positive">
        <h3>Positive</h3>
            <a href="Felicita/felicita.html"><li>Felicità</li></a>
            <a href="Serenita/serenita.html"><li>Serenità</li></a>
    </div>
    <div id="negative">
        <h3>Negative</h3>
            <a href="Tristezza/tristezza.html"><li>Tristezza</li></a>
            <a href="Paura/paura.html"><li>Paura</li></a>
    </div>
    </ul>
</div>

    <script src="app.js"></script>
    <script src="../script.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>

</html>
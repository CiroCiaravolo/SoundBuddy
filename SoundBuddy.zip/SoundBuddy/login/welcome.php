<html lang="it"></html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatibile" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> SuondBuddy</title>
    <link rel="stylesheet" href="../stili.css" >
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://unpkg.com/vue@3"></script>
    <script>
    function cerca() {
      var input;
      var f;
      var l;
      var v;
      var x;
      var i;
      var t;
      input = document.getElementById("cerca");
      f = input.value.toUpperCase();
      l = document.getElementById("lista");
      v = l.getElementsByTagName("li");
      for (i = 0; i < v.length; i++) {
          x = l.getElementsByTagName("li")[i];
          t = x.textContent || x.innerText;
          if (t.toUpperCase().indexOf(f) > -1) {
              v[i].style.display = "";
          } else {
              v[i].style.display = "none";
          }
      }
    }
    $(document).ready(function(){
        $("#bottone_1").click(function(){
        $("#negative").hide();
        $("#positive").show();
        $("#positive").css("color", "red");
        });
        $("#bottone_2").click(function(){
        $("#positive").hide();
        $("#negative").show();
        $("#negative").css("color", "red");
        });
        $("#bottone_3").click(function() {
        $("#negative").show();
        $("#negative").css("color", "black");
        $("#positive").show();
        $("#positive").css("color", "black");
        });
    });
    $(document).ready(function () {
      $("#tutorial").hide();
      $(".filtrare").click(function () {
        $("#tutorial").animate({ top: '32.5em' });
        $("#tutorial").text("clicca qui");
      });
      $(".filtrare").mouseleave(function () {
        $("#tutorial").fadeOut();
        $("#tutorial").text("Tutorial");
      });
      $(".filtrare").mouseenter(function () {
        $("#tutorial").fadeIn();
      });
      $(".cercare").click(function () {
        $("#tutorial").animate({ top: '36em' });
        $("#tutorial").text("cerca qui");
      });
      $(".cercare").mouseleave(function () {
        $("#tutorial").fadeOut();
        $("#tutorial").text("Tutorial");
      });
      $(".cercare").mouseenter(function () {
        $("#tutorial").fadeIn();
      });
      $(".scegliere").click(function () {
        $("#tutorial").animate({ top: '42em' });
        $("#tutorial").text("scegli qui");
      });
      $(".scegliere").mouseleave(function () {
        $("#tutorial").fadeOut();
        $("#tutorial").text("Tutorial");
      });
      $(".scegliere").mouseenter(function () {
        $("#tutorial").fadeIn();
      });
      $(".filtra").click(function () {
        $(".movimento").slideToggle();
      });
    });
    window.addEventListener('pageshow', function(event) {
      if (event.persisted) {
        window.location.reload();
      }
    });

    $(window).focus(function() {
      window.location.reload();
    });
    </script>
    </head>

    <body>
        <header>
        <p class="welcome-message">
        <?php
          session_start();
          if (!isset($_SESSION['username'])) {
            header("Location: ../index8.html");
            exit();
          }
          $username = $_SESSION['username'];
          echo "<script>const username = '$username';</script>";
          echo "Welcome $username";
        ?>
        <div class="logo">
          <img src="../logo.jpg.png"/>
        </div>
        </p>
        <nav class="navigation">
        <div class="btn-logout">
  <form method="post" action="logout.php">
    <button type="submit" class="btn" formaction="logout.php">LogOut</button>
  </form>
</div>

          <div id='app'>
          <div class="playlist">
            <h3>Playlist</h3>
              <div v-if="!isEditing">
                <input type="text" class="short_input" v-model="music">
                <input type="submit" value="add" @click="allMusic">
                <button @click="reset()">Reset</button>
              </div>
              <div v-else>
                <input type="text" class="short_input" v-model="music">
                <input type="submit" value="update" @click="updateMusic">
                <button @click="reset()">Reset</button>
              </div>
              <ol>
                <li v-for="(music, index) in all">
                  <a :href="musicLink[music]">{{ music }}</a>
                  <button @click="editMusic(index, music)">Edit</button>
                  <button @click="deleteMusic(index)">Delete</button>
                </li>
              </ol>
          </div>
        </div>
        </nav>  
        <button id="tutorial" style="position: absolute;">Tutorial</button>
</header>

<video src="../video_ragazza.mp4" muted loop autoplay></video>
<div class="overlay"></div>

<div class="box">
<p>Soundbuddy è un sito progettato per consigliarti la musica migliore per TE, </br>
   in funzione del tuo umore, tutto questo con un solo click</p>
    <h2>LE TUE SENSAZIONI LA NOSTRA PREOCCUPAZIONE</h2>
    </br>
    <h1>Come ti senti?</h1>
    <button class="filtrare">Filtrare</button>
    <button class="cercare">Cercare</button>
    <button class="scegliere">Scegliere</button>
    <h3 class="filtra">Filtra</h3>
    <h3 class="movimento" style="display: none;">Filtra le tue emozioni</h3>
    <button id="bottone_1" class="movimento" style="display: none;">Positive</button>
    <button id="bottone_2" class="movimento" style="display: none;">Negative</button>
    <button id="bottone_3" class="movimento" style="display: none;">Reset</button>
    <input type="text" id="cerca" name="emozioni" placeholder="Inserisci..." size="30" maxlength="30" onkeyup="cerca()">
    <!--
      <input type="submit" name="" value="Start">
    -->
    <ul id="lista" style="list-style-type:none;">
    </br>
    <h2>Emozioni</h2>
    <div id="positive">
        <h3>Positive</h3>
            <a href="Felicita/felicita.php"><li>Felicità</li></a>
            <a href="Chill/chill.php"><li>Chill</li></a>
            <a href="Divertimento/divertimento.php"><li>Divertimento</li></a>
            <a href="Innamorato/Innamorato.php"><li>Innamorato</li></a>
            <a href="Amicizia/Amicizia.php"><li>Amicizia</li></a>
    </div>
    <div id="negative">
        <h3>Negative</h3>
            <a href="Tristezza/tristezza.php"><li>Tristezza</li></a>
            <a href="Paura/paura.php"><li>Paura</li></a>
            <a href="Solitudine/solitudine.php"><li>Solitudine</li></a>
            <a href="Ansia/ansia.php"><li>Ansia</li></a>
            <a href="Rabbia/rabbia.php"><li>Rabbia</li></a>
    </div>
    </ul>
</div>

    <script src="app.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>

</html>
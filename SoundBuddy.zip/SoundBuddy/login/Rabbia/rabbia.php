<!DOCTYPE HTML>
<html>

<head>
  <title>Rabbia</title>
  <link rel="stylesheet" href="stile_angry.css">
  <script src="https://unpkg.com/vue@3"></script>
</head>
<body background="../Rabbia/ .jpg">
  <?php
    session_start();
    if (isset($_SESSION['username'])) {
      $username = $_SESSION['username'];
      echo "<script>const username = '$username';</script>";
    }
  ?>
<a href="../welcome.php">Back</a>
<h1>Sei arrabbiato ma queste canzoni ti faranno sbollire</h1>
  <div id='app'>
  <span class="musica" onmouseover="caricaDocumento(event)">musica_1</span> <input type="checkbox" id="musica_1" value="Sabbie d'oro" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_2</span> <input type="checkbox" id="musica_2" value="Yes Indeed" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_3</span> <input type="checkbox" id="musica_3" value="Jimmy Cooks" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_4</span> <input type="checkbox" id="musica_4" value="Cavalcata delle Valchirie" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_5</span> <input type="checkbox" id="musica_5" value="Salsa" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_6</span> <input type="checkbox" id="musica_6" value="Whatever It Takes" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_7</span> <input type="checkbox" id="musica_7" value="Slang" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_8</span> <input type="checkbox" id="musica_8" value="Big Poppa" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_9</span> <input type="checkbox" id="musica_9" value="XDVRMX" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_10</span> <input type="checkbox" id="musica_10" value="F.N" class="star" v-model="all" @change="save">
  <br />
  <span class="testo" onmouseover="caricaDocumento(event)">testo_1</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_2</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_3</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_4</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_5</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_6</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_7</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_8</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_9</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_10</span>
  </div>
  <hr />
  <div id="zona_musica">
    Musica
  </div>
  <hr />
  <div id="zona_testo">
    Testo
  </div>
  <hr />
  <script>
    function caricaDocumento(e) {
      var httpRequest = new XMLHttpRequest();
      httpRequest.prevTarget = e.target;
      httpRequest.onreadystatechange = gestisciResponse;
      httpRequest.open("GET", e.target.innerHTML + ".html", true);
      httpRequest.send();
    }
    function gestisciResponse(e) {
      if (e.target.readyState == 4 && e.target.status == 200) {
        document.getElementById("zona_" +
          e.target.prevTarget.getAttribute("class")).innerHTML =
          e.target.responseText;
      }
    } 
  </script>
</body>
<script src="../app.js"></script>
</html>
<!DOCTYPE HTML>
<html>

<head>
  <title>Amicizia</title>
  <link rel="stylesheet" href="stile_friendship.css">
  <script src="https://unpkg.com/vue@3"></script>
</head>
  <body background="../Amicizia/Friendship.jpg">
  <?php
    session_start();
    if (isset($_SESSION['username'])) {
      $username = $_SESSION['username'];
      echo "<script>const username = '$username';</script>";
    }
  ?>
<a href="../welcome.php">Back</a>
  <h1>Trovare amici che ti capiscano è un altro tipo di lusso</h1>
  <div id='app'>
  <span class="musica" onmouseover="caricaDocumento(event)">musica_1</span> <input type="checkbox" id="musica_1" value="Ne è Valsa la pena" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_2</span> <input type="checkbox" id="musica_2" value="Bro + Bro" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_3</span> <input type="checkbox" id="musica_3" value="Mezza Siga" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_4</span> <input type="checkbox" id="musica_4" value="Wild Bandana" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_5</span> <input type="checkbox" id="musica_5" value="Mon Fre" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_6</span> <input type="checkbox" id="musica_6" value="Hotel Lobby" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_7</span> <input type="checkbox" id="musica_7" value="Mai Brillo" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_8</span> <input type="checkbox" id="musica_8" value="Ulala" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_9</span> <input type="checkbox" id="musica_9" value="Oh mama" class="star" v-model="all" @change="save">
  <span class="musica" onmouseover="caricaDocumento(event)">musica_10</span> <input type="checkbox" id="musica_10" value="Se rinasco" class="star" v-model="all" @change="save">
  <br />
  <span class="testo" onmouseover="caricaDocumento(event)">testo_1</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_2</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_3</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_4</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_5</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_6</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_7</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_8</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_9</span>
  <span class="testo" onmouseover="caricaDocumento(event)">testo_10</span>
  </div>
  <hr />
  <div id="zona_musica">
    Musica
  </div>
  <hr />
  <div id="zona_testo">
    Testo
  </div>
  <hr />
  <script>
    function caricaDocumento(e) {
      var httpRequest = new XMLHttpRequest();
      httpRequest.prevTarget = e.target;
      httpRequest.onreadystatechange = gestisciResponse;
      httpRequest.open("GET", e.target.innerHTML + ".html", true);
      httpRequest.send();
    }
    function gestisciResponse(e) {
      if (e.target.readyState == 4 && e.target.status == 200) {
        document.getElementById("zona_" +
          e.target.prevTarget.getAttribute("class")).innerHTML =
          e.target.responseText;
      }
    } 
  </script>
</body>
<script src="../app.js"></script>
</html>
<?php
if ($_SERVER["REQUEST_METHOD"] != "POST") {
  header("Location: /");
}
else {
    $dbconn = pg_connect("host=localhost port=5432 dbname=soundbuddy
    user=postgres password=Cirorita1") 
                or die('Could not connect: ' . pg_last_error());
}
?>
<!DOCTYPE html>
<html>
    <head></head>
    <body>
        <?php
            if ($dbconn) {
                $email = $_POST['inputEmail'];
                $q1 = "select * from utente where email= $1";
                $result = pg_query_params($dbconn, $q1, array($email));
                if (!($tuple=pg_fetch_array($result, null, PGSQL_ASSOC))) {
                    header("Location: ../index3.html");
                }
                else {
                    $domanda = $_POST['domanda'];
                    $password_dimenticata = $_POST['inputPasswordDimenticata'];
                    $new_password = password_hash($_POST['new_inputPassword'], PASSWORD_DEFAULT);

                    if ($domanda == $tuple['domanda'] && password_verify($password_dimenticata, $tuple['paswd_dimenticata'])) {
                        $q2 = "update utente set paswd = $1 WHERE email = $2";
                        $result = pg_query_params($dbconn, $q2, array($new_password, $email));
                        
                        if (pg_affected_rows($result) > 0) {
                            header("Location: ../index5.html");
                        } else {
                            header("Location: ../index6.html");
                        }
                    }
                    else {
                        header("Location: ../index6.html");
                    }
                }
            }
        ?> 
    </body>
</html>

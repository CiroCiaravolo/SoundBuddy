<!DOCTYPE HTML>
<html>

<head>
  <title>Innamorato</title>
  <link rel="stylesheet" href="stile_love.css">
  <script src="https://unpkg.com/vue@3"></script>
</head>
<body background="../Innamorato/pink.jpg">
  <?php
    session_start();
    if (isset($_SESSION['username'])) {
      $username = $_SESSION['username'];
      echo "<script>const username = '$username';</script>";
    }
  ?>
<a href="../welcome.php">Back</a>
<h1>L'amore è il sentimento più puro che si possa provare</h1>
  <span class="musica">musica_1</span>
  <span class="musica">musica_2</span>
  <span class="musica">musica_3</span>
  <span class="musica">musica_4</span>
  <span class="musica">musica_5</span>
  <span class="musica">musica_6</span>
  <span class="musica">musica_7</span>
  <span class="musica">musica_8</span>
  <span class="musica">musica_9</span>
  <span class="musica">musica_10</span>
  <br />
  <span class="testo">testo_1</span>
  <span class="testo">testo_2</span>
  <span class="testo">testo_3</span>
  <span class="testo">testo_4</span>
  <span class="testo">testo_5</span>
  <span class="testo">testo_6</span>
  <span class="testo">testo_7</span>
  <span class="testo">testo_8</span>
  <span class="testo">testo_9</span>
  <span class="testo">testo_10</span>
  <hr />
  <div id='app'>
  <div v-if="!isEditing">
    <input type="text" v-model="music">
    <input type="submit" value="add" @click="allMusic">
    <button @click="reset()">Reset</button>
  </div>
  <div v-else>
    <input type="text" v-model="music">
    <input type="submit" value="update" @click="updateMusic">
    <button @click="reset()">Reset</button>
  </div>
  <ol>
    <li v-for="(music, index) in all">
      <a :href="musicLink[music]">{{ music }}</a>
      <button @click="editMusic(index, music)">Edit</button>
      <button @click="deleteMusic(index)">Delete</button>
    </li>
  </ol>
  <input type="checkbox" id="musica_1" value="Non Abbiamo eta" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_2" value="Ti amo" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_3" value="La Musica non c'è" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_4" value="Tango" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_5" value="Tu Te scurdat e m" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_6" value="Ti Amo" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_7" value="I Want It That Way" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_8" value="I love you Baby" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_9" value="Sarà perchè ti amo" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_10" value="M'manc" class="star" v-model="all" @change="save">

  </div>
  <div id="zona_musica">
    Musica
  </div>
  <hr />
  <div id="zona_testo">
    Testo
  </div>
  <hr />
  <script>
    var documenti = document.getElementsByTagName("span");
    for (var i = 0; i < documenti.length; i++) {
      documenti[i].onmouseover = caricaDocumento;
    }
    function caricaDocumento(e) {
      var httpRequest = new XMLHttpRequest();
      httpRequest.prevTarget = e.target;
      httpRequest.onreadystatechange = gestisciResponse;
      httpRequest.open("GET", e.target.innerHTML + ".html", true);
      httpRequest.send();
    }
    function gestisciResponse(e) {
      if (e.target.readyState == 4 && e.target.status == 200) {
        document.getElementById("zona_" +
          e.target.prevTarget.getAttribute("class")).innerHTML =
          e.target.responseText;
      }
    } 
  </script>
</body>
<script src="../app.js"></script>
</html>
<!DOCTYPE HTML>
<html>

<head>
  <title>Divertimento</title>
  <link rel="stylesheet" href="stile_fun.css">
  <script src="https://unpkg.com/vue@3"></script>
</head>
<body background="../Divertimento/page.jpg">
<?php
    session_start();
    if (isset($_SESSION['username'])) {
      $username = $_SESSION['username'];
      echo "<script>const username = '$username';</script>";
    }
  ?>
  <a href="../welcome.php">Back</a>
    <h1>Hai bisogno di divertirti? Ecco i nostri consigli per te</h1>
    <span class="musica">musica_1</span>
    <span class="musica">musica_2</span>
    <span class="musica">musica_3</span>
    <span class="musica">musica_4</span>
    <span class="musica">musica_5</span>
    <span class="musica">musica_6</span>
    <span class="musica">musica_7</span>
    <span class="musica">musica_8</span>
    <span class="musica">musica_9</span>
    <span class="musica">musica_10</span>
    <br />
    <span class="testo">testo_1</span>
    <span class="testo">testo_2</span>
    <span class="testo">testo_3</span>
    <span class="testo">testo_4</span>
    <span class="testo">testo_5</span>
    <span class="testo">testo_6</span>
    <span class="testo">testo_7</span>
    <span class="testo">testo_8</span>
    <span class="testo">testo_9</span>
    <span class="testo">testo_10</span>
    <br>
  <hr />
  <div id='app'>
  <div v-if="!isEditing">
    <input type="text" v-model="music">
    <input type="submit" value="add" @click="allMusic">
    <button @click="reset()">Reset</button>
  </div>
  <div v-else>
    <input type="text" v-model="music">
    <input type="submit" value="update" @click="updateMusic">
    <button @click="reset()">Reset</button>
  </div>
  <ol>
    <li v-for="(music, index) in all">
      <a :href="musicLink[music]">{{ music }}</a>
      <button @click="editMusic(index, music)">Edit</button>
      <button @click="deleteMusic(index)">Delete</button>
    </li>
  </ol>
  <input type="checkbox" id="musica_1" value="Macarena" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_2" value="Don't Stop Me Now" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_3" value="Good Vibrations" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_4" value="Bailando" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_5" value="Mon Amour" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_6" value="Giovani Wannabe" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_7" value="Fantastica" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_8" value="Wake Me Up" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_9" value="I Don't Care" class="star" v-model="all" @change="save">
  <input type="checkbox" id="musica_10" value="Somebody To You" class="star" v-model="all" @change="save">

  </div>
    <div id="zona_musica">
      Musica
    </div>
  <hr />
  <div id="zona_testo">
    Testo
  </div>
  <hr />
  <script>
    var documenti = document.getElementsByTagName("span");
    for (var i = 0; i < documenti.length; i++) {
      documenti[i].onmouseover = caricaDocumento;
    }
    function caricaDocumento(e) {
      var httpRequest = new XMLHttpRequest();
      httpRequest.prevTarget = e.target;
      httpRequest.onreadystatechange = gestisciResponse;
      httpRequest.open("GET", e.target.innerHTML + ".html", true);
      httpRequest.send();
    }
    function gestisciResponse(e) {
      if (e.target.readyState == 4 && e.target.status == 200) {
        document.getElementById("zona_" +
          e.target.prevTarget.getAttribute("class")).innerHTML =
          e.target.responseText;
      }
    } 
  </script>
</body>
<script src="../app.js"></script>
</html>
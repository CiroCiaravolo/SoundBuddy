<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: /");
}
else {
    $dbconn = pg_connect("host= port= dbname=
        user= password=") 
                or die('Could not connect: ' . pg_last_error());
}
?>
<!DOCTYPE html>
<html>
    <head></head>
    <body>
    <?php
        if ($dbconn) {
            unset($_SESSION['email']);
            header("location: ../SoundBuddy.html");
            exit;
        }
    ?> 
    </body>
</html>
<?php
if ($_SERVER["REQUEST_METHOD"] != "POST") {
  header("Location: /");
}
else {
  $dbconn = pg_connect("host= port= dbname=
  user= password=") 
                or die('Could not connect: ' . pg_last_error());
}

  session_start();
  session_unset();
  session_destroy();
  header("Location: ../SoundBuddy.html");
  exit;
?>
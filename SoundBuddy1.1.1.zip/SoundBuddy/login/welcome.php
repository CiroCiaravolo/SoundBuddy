<html lang="it"></html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatibile" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> SuondBuddy</title>
    <link rel="stylesheet" href="../stili.css" >
    <script src="https://code.jquery.com/jquery-3.6.4.min.js">
  </script>
    <script>
    $(document).ready(function(){
        $("#bottone1").click(function(){
        $("#positive").empty();
        $("#negative").css("color", "red");
        });
        $("#bottone2").click(function(){
        $("#negative").empty();
        $("#positive").css("color", "red");
        });
    });
    </script>
    </head>

<body>
<header>
        <p class="welcome-message">
        <?php
            $username=$_GET['username'];
            echo "Welcome $username";
        ?>
        </p>
        <img src="../logo.jpg.png"/>
        <nav class="navigation">
            <a href="#"> Home</a>
            <a href="#"> About</a>
            <a href="#"> Servizi</a>
            <a href="#"> Contatti</a>
        </nav>  
</header>

<video src="../video_ragazza.mp4" muted loop autoplay></video>

<div class="overlay"></div>
<div class="text">
    <p>Soundbuddy è un sito progettato per consigliarti la musica migliore per TE, in funzione del tuo umore, tutto questo con un solo click</p>
    <h2>LE TUE SENSAZIONI LA NOSTRA PREOCCUPAZIONE</h2>
</div>
<div class="box">
    </br>
    <h1>Come ti senti?</h1>
    <h3>Se vuoi puoi filtrare le tue emozioni con un solo click</h3>
    <button id="bottone2">Positive</button>
    <button id="bottone1">Negative</button>
    </br>
    <input type="text" id="cerca" name="emozioni" placeholder="Inserisci..." size="30" maxlength="30">
    <input type="submit" name="" value="Start" onclick="cerca()">
    <ul id="lista" style="list-style-type:none;">
    </br>
    <h2>Emozioni</h2>
    <div id="positive">
        <h3>Positive</h3>
            <a href="Felicita/felicita.html"><li>Felicità</li></a>
            <a href="Serenita/serenita.html"><li>Serenità</li></a>
    </div>
    <div id="negative">
        <h3>Negative</h3>
            <a href="Tristezza/tristezza.html"><li>Tristezza</li></a>
            <a href="Paura/paura.html"><li>Paura</li></a>
    </div>
    </ul>
</div>

<script src="../script.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>